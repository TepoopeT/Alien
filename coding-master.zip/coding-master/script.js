var p = document.querySelectorAll('p')
console.log(p)
var a = document.querySelectorAll('.a')
console.log(a)
var id = document.querySelector("#myP")
console.log(id)

id.addEventListener('click',()=>{
    console.log("Clicked")
})